USER_AGENT = 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_6_7) AppleWebKit/534.24 (KHTML, like Gecko) Iron/11.0.700.2 Chrome/11.0.700.2 Safari/534.24'
FEED_FORMAT = 'csv'
FEED_EXPORT_ENCODING = 'utf-8'
DOWNLOAD_DELAY = 0.25

# FEED_EXPORTERS = {
#     'xml': 'scrappers.exporters.exporters.MyXmlExportPipeline'
# }